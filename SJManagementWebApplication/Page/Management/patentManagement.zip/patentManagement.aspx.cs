﻿using SJManagementWebApplication.Db;
using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Web.UI;
using DevExpress.Web;
using System.Web;
using System.Collections.Generic;
using SJManagementWebApplication.Code;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using DevExpress.ChartRangeControlClient.Core;
using System.Configuration;
using DevExpress.XtraPrinting;
using System.Threading;
using DevExpress.Web.Data;
using System.Collections;

namespace SJManagementWebApplication
{
    public partial class patentManagement : System.Web.UI.Page
    {
        #region Init

        //sql부
        StringBuilder sbQuery = new StringBuilder();
        Dictionary<string, string> dCondition = new Dictionary<string, string>();
        SqlCommand scCmd = new SqlCommand();
        SqlDataSource sdsDatasource = new SqlDataSource();
        //입력 폼 내용
        string sSeq, sName, sInventor, sNum, sAppnum, sFillStart, sFillEnd, sRegStart, sRegEnd, sDiv;
        //검색 폼 내용 - GridView Colum
        string[] columsToRemove = new string[]
        {
            "ip_name", "ip_inventor", "ip_division",
            "ip_filldate", "ip_num","ip_regDate", "ip_appnum"
        };

        //검색 폼 내용 - Popup 검색
        string[] searchCaptionsArr = new string[]
        {
            "특허명", "발명자", "종류", "출원일자", "특허번호","등록일자", "출원번호"
        };
        //버튼 세팅+그리드뷰 바인딩+팝업
        protected void Page_Init(object sender, EventArgs e)
        {
            Print.debugWrite("sender:", sender.ToString(), e.ToString());

            //바인딩
            gdPatentManage.AutoGenerateColumns = true;
            sdsDatasource.SelectCommand = "SELECT * FROM [ipManage]";
            string sConnString = ConfigurationManager.ConnectionStrings["WEBAPPConnectionString"].ConnectionString;
            sdsDatasource.ConnectionString = sConnString;
            gdPatentManage.DataSource = sdsDatasource;
            gdPatentManage.DataBind();

            filterSummaryInit();
        }
        //로드 시 실행
        protected void Page_Load(object sender, EventArgs e)
        {
            spPagecount.Text = "/ " + gdPatentManage.PageCount;
            //spPagecount.Text = "/ " + gdPatentManage.PageCount;

            Session["prevPage"] = "Management/patentManagement"; //세션에 로그인 후 이동할 페이지 이름 저장
            filterSummary.Visible = true;
        }
        //FIlter 초기화
        protected void filterSummaryInit()
        {
            //GridView Row 값 읽기
            int i = gdPatentManage.VisibleRowCount;

            string pagerSmy = gdPatentManage.SummaryText.ToString();

            pagerSmy = "총 " + i + "건";

            //Pager Summary에 출력
            filterSummary.Text = pagerSmy.Trim();
        }

        #endregion

        #region Management(검색 & 팝업)


            #region FIlterControl
            // GridView Colum 삭제
            protected void gdPatentManage_FilterControlColumnsCreated(object source, FilterControlColumnsCreatedEventArgs e)
            {
                foreach (string col in columsToRemove)
                    e.Columns.Remove(col);
            }
            //전체보기 Button - Filter 초기화
            protected void FilterSortClear(object sender, EventArgs e)
            {
                //Toolbar 숨김 및 Filter 초기화
                gdPatentManage.Settings.ShowFilterBar = GridViewStatusBarMode.Hidden;
                gdPatentManage.FilterExpression = "";
                filteredControl("");
                filterSummaryState();

                //Pager 초기화
                filterSummaryInit();
                gdPatentManage.ClearSort();
            }
            //검색 Reset 버튼 - Filter 초기화
            protected void onFilterResetBtnClick(object sender, EventArgs e)
            {
                //Toolbar 숨김 및 Filter 초기화
                gdPatentManage.Settings.ShowFilterBar = GridViewStatusBarMode.Hidden;
                gdPatentManage.FilterExpression = "";
                filteredControl("");
                filterSummaryState();
                toolbarSearchPopup.ShowOnPageLoad = false; //팝업창 종료

                //Pager 초기화
                filterSummaryInit();
                gdPatentManage.ClearSort();
            }
            //Toolbar Visible 상태 변경
            protected void filterSummaryState()
            {
                filteredTextMain.Visible = false;
                filteredText.Visible = false;
                filterResetBtn.Visible = false;
                filterLine.Visible = false;
            }
            #endregion

            #region Popup

            //Popup 실행 버튼
            protected void OnSearchClick(object source, EventArgs e) //검색 버튼
            {
                //팝업 초기화
                ip_name.Text = "";
                ip_inventor.Text = "";
                //Null 오류 발생시 디버그 출력
                try
                {
                    ip_division.SelectedItem.Selected = false;
                }
                catch (NullReferenceException exception)
                {
                    Print.debugWrite("Popup Debug : ", exception.ToString());
                }
                ip_division.Text = "";
                ip_fillDateStart.Text = "";
                ip_fillDateEnd.Text = "";
                ip_regDateStart.Text = "";
                ip_regDateEnd.Text = "";
                ip_num.Text = "";
                ip_appnum.Text = "";

                //검색 Popup 출력
                toolbarSearchPopup.ShowOnPageLoad = true;
            }
            //Popup 내부 검색 버튼
            protected void onSearchMatchData(object sender, EventArgs e)
            {
                //검색 조건
                string filterExpression = filterExpressionControl();

                gdPatentManage.FilterExpression = filterExpression;
                filteredControl(filterExpression);
                pagerSummary();

                //Toolbar 및 팝업 설정
                gdPatentManage.Settings.ShowFilterBar = GridViewStatusBarMode.Hidden;
                toolbarSearchPopup.ShowOnPageLoad = false;
                dLbSearchFilterText.Visible = true;
            }
            //Toolbar - 검색 조건 출력
            protected void filteredControl(string filterExpression)
            {
                string filteredExpression = "";

                for (int i = 0; i < columsToRemove.Length; i++)
                {
                    if (filterExpression.Contains(columsToRemove.GetValue(i).ToString()))
                    {
                        filteredExpression += searchCaptionsArr.GetValue(i).ToString();

                        if (i != columsToRemove.Length - 1)
                        {
                            filteredExpression += ", ";
                        }
                    }
                }

                //공백 제거 후 "," 제거
                filteredExpression = filteredExpression.Trim();

                if (filteredExpression.Equals("") || filteredExpression == null)
                {
                    filteredText.Text = "";

                }
                else if (filteredExpression.EndsWith(","))
                {
                    filteredExpression = filteredExpression.Substring(0, filteredExpression.Length - 1);
                    filteredText.Text = filteredExpression;
                }
                else
                    filteredText.Text = filteredExpression;
            }
            //Popup - 검색 조건 설정
            private string filterExpressionControl()
            {
                string filterExpression = "";
                sName = ip_name.Text.ToString().Trim();
                sInventor = ip_inventor.Text.ToString().Trim();
                //검색 조건 오류 - 종류
                try
                {
                    sDiv = ip_division.SelectedItem.Text.ToString().Trim();
                }
                catch (System.NullReferenceException e)
                {
                    sDiv = "";
                }
                sFillStart = ip_fillDateStart.Text.ToString().Trim();
                sFillEnd = ip_fillDateEnd.Text.ToString().Trim();
                sRegStart = ip_regDateStart.Text.ToString().Trim();
                sRegEnd = ip_regDateEnd.Text.ToString().Trim();
                sNum = ip_num.Text.ToString().Trim();
                sAppnum = ip_appnum.Text.ToString().Trim();

                //검색조건 - 특허명 (포함)
                if (!sName.Equals(""))
                    filterExpression += "Contains([" + columsToRemove.GetValue(0) + "], '" + sName + "') ";

                //검색조건 - 발명자 (포함)
                if (!sInventor.Equals(""))
                {
                    if (filterExpression.Equals(""))
                        filterExpression += "Contains([" + columsToRemove.GetValue(1) + "], '" + sInventor + "') ";
                    else
                        filterExpression += "And Contains([" + columsToRemove.GetValue(1) + "], '" + sInventor + "') ";
                }

                //검색조건 - 분류 (포함)
                if (!sDiv.Equals(""))
                {
                    if (filterExpression.Equals(""))
                        filterExpression += "Contains([" + columsToRemove.GetValue(2) + "], '" + sDiv + "') ";
                    else
                        filterExpression += "And Contains([" + columsToRemove.GetValue(2) + "], '" + sDiv + "') ";
                }

                //검색조건 - 날짜 시작 (이상)
                if (!sFillStart.Equals(""))
                {
                    if (filterExpression.Equals(""))
                        filterExpression += "[" + columsToRemove.GetValue(3) + "] >= #" + sFillStart + "# ";
                    else
                        filterExpression += "And [" + columsToRemove.GetValue(3) + "] >= #" + sFillStart + "# ";
                }

                //검색조건 - 날짜 끝 (이하)
                if (!sFillEnd.Equals(""))
                {
                    if (filterExpression.Equals(""))
                        filterExpression += "[" + columsToRemove.GetValue(3) + "] <= #" + sFillEnd + "# ";
                    else
                        filterExpression += "And [" + columsToRemove.GetValue(3) + "] <= #" + sFillEnd + "# ";
                }

                //검색조건 - 특허 번호 (포함)
                if (!sNum.Equals(""))
                {
                    if (filterExpression.Equals(""))
                        filterExpression += "Contains([" + columsToRemove.GetValue(4) + "], '" + sNum + "') ";
                    else
                        filterExpression += "And Contains([" + columsToRemove.GetValue(4) + "], '" + sNum + "') ";
                }

                //검색조건 - 날짜 시작 (이상)
                if (!sRegStart.Equals(""))
                {
                    if (filterExpression.Equals(""))
                        filterExpression += "[" + columsToRemove.GetValue(5) + "] >= #" + sRegStart + "# ";
                    else
                        filterExpression += "And [" + columsToRemove.GetValue(5) + "] >= #" + sRegStart + "# ";
                }

                //검색조건 - 날짜 끝 (이하)
                if (!sRegEnd.Equals(""))
                {
                    if (filterExpression.Equals(""))
                        filterExpression += "[" + columsToRemove.GetValue(5) + "] <= #" + sRegEnd + "# ";
                    else
                        filterExpression += "And [" + columsToRemove.GetValue(5) + "] <= #" + sRegEnd + "# ";
                }

                //검색조건 - 출원 번호 (포함)
                if (!sAppnum.Equals(""))
                {
                    if (filterExpression.Equals(""))
                        filterExpression += "Contains([" + columsToRemove.GetValue(6) + "], '" + sAppnum + "') ";
                    else
                        filterExpression += "And Contains([" + columsToRemove.GetValue(6) + "], '" + sAppnum + "') ";
                }

                return filterExpression;
            }
            #endregion

            #region Pager + Footer

            //pager 이동
            protected void submitPager(object sender, EventArgs e)
            {
                if (tbPagerinput.Text != "")
                {
                    gdPatentManage.PageIndex = int.Parse(tbPagerinput.Text) - 1;
                    spPagecount.Text = "/ " + gdPatentManage.PageCount;
                    tbPagerinput.Text = "";
                }
            }
            //Pager Summary
            protected void pagerSummary()
            {
                int i = gdPatentManage.VisibleRowCount;

                string pagerSmy = gdPatentManage.SummaryText.ToString();

                pagerSmy = "총 " + i + "건의 검색결과가 있습니다.";

                //Toolbar Visible 상태 변경
                filterSummary.Text = pagerSmy.Trim();
                dLbSearchFilterText.Visible = true;
                filteredTextMain.Visible = true;
                filteredText.Visible = true;
                filterResetBtn.Visible = true;
                filterLine.Visible = true;
            }
            //Pager
            //protected void submitPager(object sender, EventArgs e)
            //{
            //    if (tbPagerinput.Text != "")
            //    {
            //        gdPatentManage.PageIndex = int.Parse(tbPagerinput.Text) - 1;
            //        spPagecount.Text = "/ " + gdPatentManage.PageCount;
            //        tbPagerinput.Text = "";
            //    }
            //}

            #endregion

        #endregion

    }
}